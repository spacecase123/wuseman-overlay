package sconsify

type Album struct {
	URI string

	Name    string
	Artists []*Artist
}
